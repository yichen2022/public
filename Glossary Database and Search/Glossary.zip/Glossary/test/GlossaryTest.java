import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;

public class GlossaryTest {
    /**
     * Routine case - generateElements("Go Bucks", strSet), a usual string.
     */
    @Test
    public void testGenerateElementsGoBucks() {
        String str = "Go Bucks";
        Set<Character> strSet = new Set1L<Character>();
        Glossary.generateElements(str, strSet);
        assertEquals("Go Bucks", str);
        for (int i = 0; i < str.length(); i++) {
            assertTrue(strSet.contains(str.charAt(i)));
        }
    }
    /**
     * Challenging case - generateElements(" \t, ", separatorSet), has a duplicate.
     */
    @Test
    public void testSeparatorSet() {
        String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<Character>();
        Glossary.generateElements(separatorStr, separatorSet);
        assertEquals(" \t, ", separatorStr);
        for (int i = 0; i < separatorStr.length(); i++) {
            assertTrue(separatorSet.contains(separatorStr.charAt(i)));
        }
    }
    /**
     * Boundary case - generateElements("", strSet), Empty String.
     */
    @Test
    public void testEmptySetGenerateElements() {
        String str = "";
        Set<Character> strSet = new Set1L<Character>();
        Glossary.generateElements(str, strSet);
        assertTrue(strSet.size() == 0);
    }
    /**
     * Routine case - nextWordOrSeparator("O H I O", position, separatorSet), a standard string.
     */
    @Test
    public void testNextWordOrSeparatorOHIOStart() {
        String str = "O H I O";
        int position = 0;
        String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        Glossary.generateElements(separatorStr, separatorSet);
        String result = Glossary.nextWordOrSeparator(str, position,
                separatorSet);
        assertEquals("O", result);
    }
    /**
     * Challenging case - nextWordOrSeparator(" ", position, separatorSet), only a separator.
     */
    @Test
    public void testNextWordOrSeparatorSpace() {
        String str = " ";
        int position = 0;
        String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        Glossary.generateElements(separatorStr, separatorSet);
        String result = Glossary.nextWordOrSeparator(str, position,
                separatorSet);
        assertEquals(" ", result);
    }
    /**
     * Boundary case - nextWordOrSeparator("Sycamore", position, separatorSet), only a word.
     */
    @Test
    public void testNextWordOrSeparatorWithoutSeparators() {
        String str = "Sycamore";
        int position = 0;
        String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        Glossary.generateElements(separatorStr, separatorSet);
        String result = Glossary.nextWordOrSeparator(str, position,
                separatorSet);
        assertEquals("Sycamore", result);
    }
    /**
     * Routine case - nextWordOrSeparator("Go Aves", position, separatorSet), sentence.
     */
    @Test
    public void testNextWordOrSeparatorGoAvesStartSeparator() {
        String str = "Go Aves";
        String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        Glossary.generateElements(separatorStr, separatorSet);
        int position = 0;
        while (!separatorSet.contains(str.charAt(position))) {
            position++;
        }
        String result = Glossary.nextWordOrSeparator(str, position,
                separatorSet);
        assertEquals(" ", result);
    }
    /**
     * Challenging case - processDictionary(dictionary, in), has a multi-line definition.
     */
    @Test
    public void testProcessDictionarySampleFile() {
        SimpleReader in = new SimpleReader1L("terms.txt");
        Queue<String> dictionary = new Queue1L<String>();
        Glossary.processDictionary(dictionary, in);
        Set<String> terms = Glossary.makeTerms(dictionary);
        for (String str : dictionary) {
            int n = str.indexOf(" ");
            assertTrue(terms.contains(str.substring(0, n)));
        }
    }
    /**
     * Boundary case - processDictionary(dictionary, in), is an empty file.
     */
    @Test
    public void testProcessDictionaryBlankFile() {
        SimpleReader in = new SimpleReader1L("Blank.txt");
        Queue<String> dictionary = new Queue1L<String>();
        Glossary.processDictionary(dictionary, in);
        Set<String> terms = Glossary.makeTerms(dictionary);
        assertTrue(terms.size() == 0);
    }
    /**
     * Routine case - processDictionary(dictionary, in), has only single-line definitions.
     */
    @Test
    public void testProcessDictionarySATWords() {
        SimpleReader in = new SimpleReader1L("SAT.txt");
        Queue<String> dictionary = new Queue1L<String>();
        Glossary.processDictionary(dictionary, in);
        Set<String> terms = Glossary.makeTerms(dictionary);
        for (String str : dictionary) {
            int n = str.indexOf(" ");
            assertTrue(terms.contains(str.substring(0, n)));
        }
    }
}
