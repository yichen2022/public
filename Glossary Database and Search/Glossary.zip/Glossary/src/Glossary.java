import java.util.Comparator;

import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Yi Chen
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";
        for (int i = 0; i < str.length(); i++) {
            if (!strSet.contains(str.charAt(i))) {
                strSet.add(str.charAt(i));
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String result = "";
        int temp = position;
        if (separators.contains(text.charAt(position))) {
            temp++;
            result = result + text.charAt(position);
        } else {
            while (temp < text.length()
                    && !separators.contains(text.charAt(temp))) {
                temp++;
            }
            result = text.substring(position, temp);
        }
        return result;
    }

    /**
     * Stores the words and definitions in a map where word is the key and
     * definition is the value.
     *
     * @param m
     *            The queue created.
     * @param in
     *            The input stream.
     * @requires m.length() == 0; in.isOpen(); m is not null
     * @ensures m will be a queue with all the words and definitions
     */
    public static void processDictionary(Queue<String> m, SimpleReader in) {
        assert in.isOpen() : "Violation of: in.isOpen()";
        assert m != null : "Violation of: m is not null";
        while (!in.atEOS()) {
            String term = "";
            /*
             * Concatenates strings more efficiently. Will be used in the loop
             * later on.
             */
            StringBuilder builder = new StringBuilder();
            builder.append(term);
            /*
             * Makes sure that the term is not an empty line. There may be
             * multiple lines.
             */
            String str = in.nextLine();
            //Process multiple line definitions.
            int i = 0;
            while (!str.equals("")) {
                builder.append(str);
                if (i == 0) {
                    builder.append(" ");
                }
                if (!in.atEOS()) {
                    str = in.nextLine();
                } else {
                    str = "";
                }
            }
            term = builder.toString();
            //Adds the term and definition to the queue.
            m.enqueue(term);
            Comparator<String> order = new StringComparator();
            m.sort(order);
        }
    }

    /**
     * Returns a set of terms from the dictionary. This is the helper method of
     * processDictionary.
     *
     * @param dictionary
     *            The dictionary that terms should be made.
     * @requires dictionary != null
     * @ensures dictionary = #dictionary
     * @return a set of the terms.
     */
    public static Set<String> makeTerms(Queue<String> dictionary) {
        assert dictionary != null : "Violation of: dictionary is not null";
        Set<String> q = new Set1L<String>();
        final String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        generateElements(separatorStr, separatorSet);
        for (String str : dictionary) {
            int position = 0;
            while (!separatorSet.contains(str.charAt(position))) {
                position++;
            }
            q.add(str.substring(0, position));
        }
        return q;
    }

    /**
     * Creates the HTML glossary page with terms.
     *
     * @param m
     *            the dictionary queue
     * @param out
     *            the output stream
     * @param d
     *            the destination
     * @requires m.length() > 0 out.isOpen(); d is not null; m is not null;
     * @ensures m = #m
     */
    public static void processOutputFiles(Queue<String> m, SimpleWriter out,
            String d) {
        assert out.isOpen() : "Violation of: out.isOpen()";
        assert m != null : "Violation of: m is not null";
        assert d != null : "Violation of: d is not null";
        //Generates the list of separators.
        final String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<>();
        generateElements(separatorStr, separatorSet);
        Set<String> terms = makeTerms(m);
        //Header information.
        out.println("<h1>Glossary</h1>");
        out.println("<h2>Index</h2>");
        /*
         * Processes each term in each individual file named by term.html and
         * each term as an item in the list.
         */
        out.println("<ul>");
        for (String str : m) {
            int position = 0;
            while (!separatorSet.contains(str.charAt(position))) {
                position++;
            }
            SimpleWriter term = new SimpleWriter1L(
                    d + "/" + str.substring(0, position) + ".html");
            out.println("<li><a href = " + str.substring(0, position) + ".html>"
                    + str.substring(0, position) + "</a></li>");
            term.println("<h2><b><i><font color = 'red'>"
                    + str.substring(0, position) + "</font></i></b></h1>");
            term.print("<p>");
            //Creates links to any words in the definitions that are terms.
            while (position < str.length()) {
                String token = nextWordOrSeparator(str, position, separatorSet);
                if (terms.contains(token)) {
                    term.print(
                            "<a href = " + token + ".html>" + token + "</a>");
                } else {
                    term.print(token);
                }
                position += token.length();
            }
            //Prints the return to index in order to return to the main page.
            term.print("<p>Return to " + "<a href = 'index.html'>index</a>");
            term.print("</p>");
            term.close();
        }
        out.println("</ul>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        //Asks the user for the input file.
        out.print("Enter the name of the input file: ");
        String fileName = in.nextLine();
        //Asks the user for the location of the  files.
        out.print("Where do you want the file to be saved? ");
        String destination = in.nextLine();
        //Creates a queue with terms and definitions.
        Queue<String> dictionary = new Queue1L<String>();
        //Creates the dictionary.
        processDictionary(dictionary, new SimpleReader1L(fileName));
        SimpleWriter outputFile = new SimpleWriter1L(
                destination + "/index.html");
        //Creates the HTML page.
        processOutputFiles(dictionary, outputFile, destination);
        in.close();
        out.close();
    }

}
