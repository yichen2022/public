import java.util.Comparator;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class StringComparator implements Comparator<String> {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */

    @Override
    public int compare(String a, String b) {
        int result = 0;
        if (a.compareTo(b) < 0) {
            result = -1;
        } else if (a.compareTo(b) > 0) {
            result = 1;
        }
        return result;
    }
}
