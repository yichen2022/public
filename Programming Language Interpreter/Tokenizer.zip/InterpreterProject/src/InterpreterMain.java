import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Yi Chen
 *
 */
public final class InterpreterMain {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private InterpreterMain() {
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        /*
         * Get input file name
         */
        String fileName = args[0];
        SimpleReader file = new SimpleReader1L(fileName);
        Tokenizer t = new Tokenizer(file);
        t.print();
        file.close();
    }

}
