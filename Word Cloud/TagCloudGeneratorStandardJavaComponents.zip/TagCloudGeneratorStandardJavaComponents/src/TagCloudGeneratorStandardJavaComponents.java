import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Put a short phrase describing the program here.
 *
 * @author Yi Chen, Juntong Song, Zhou Xu
 */
public final class TagCloudGeneratorStandardJavaComponents {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGeneratorStandardJavaComponents() {
    }

    /**
     *
     */
    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";
        for (int i = 0; i < str.length(); i++) {
            if (!strSet.contains(str.charAt(i))) {
                strSet.add(str.charAt(i));
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String result = "";
        int temp = position;
        if (separators.contains(text.charAt(position))) {
            temp++;
            result = result + text.charAt(position);
        } else {
            while (temp < text.length()
                    && !separators.contains(text.charAt(temp))) {
                temp++;
            }
            result = text.substring(position, temp);
        }
        return result;
    }

    /**
     * Creates the words in the input file.
     *
     * @param in
     *            the input stream.
     * @return A queue that contains all the words in the input file.
     */
    private static ArrayList<String> makeWords(BufferedReader in) {
        ArrayList<String> seq = new ArrayList<String>();
        Set<String> words = new HashSet<String>();
        //This is the separator string including punctuation marks.
        final String separatorStr = " \t\n\r,-.!?[] {}';:/()\"*_";
        Set<Character> separatorSet = new HashSet<Character>();
        generateElements(separatorStr, separatorSet);
        //Iterates over the lines of the input to create the queue of words.
        String current = null;
        try {
            current = in.readLine();
        } catch (IOException e) {
            System.err.println("There is a problem with reading the input.");
        }
        while (current != null) {
            int position = 0;
            while (position < current.length()) {
                String str = nextWordOrSeparator(current, position,
                        separatorSet).toLowerCase();
                if (separatorStr.indexOf(str) == -1 && !words.contains(str)) {
                    seq.add(str);
                    words.add(str);
                }
                position += str.length();
            }
            current = null;
            try {
                current = in.readLine();
            } catch (IOException e) {
                System.err
                        .println("There is a problem with reading the input.");
            }
        }
        return seq;
    }

    /**
     * Counts the number of times each word appears and stores them in a
     * sequence.
     *
     * @param in
     *            The input stream
     * @param q
     *            The queue of words generated
     * @param file
     *            The input file
     * @return A sequence that contains all the integer counts.
     * @ensures The length of the sequence will be same as q.length();
     */
    private static ArrayList<Integer> counts(BufferedReader in, Set<String> q,
            String file) throws FileNotFoundException {
        ArrayList<String> seq = new ArrayList<String>();
        for (String s : q) {
            seq.add(s);
        }
        ArrayList<Integer> counts = new ArrayList<Integer>();
        for (int i = 0; i < seq.size(); i++) {
            //Separators to help separate words which includes punctuation marks.
            final String separatorStr = " \t\n\r,-.!?[] {}';:/()\"*_";
            Set<Character> separatorSet = new HashSet<>();
            generateElements(separatorStr, separatorSet);
            //Count showing the number of times that word appears.
            int count = 0;
            //Creates the input stream to read many times.
            BufferedReader input = new BufferedReader(new FileReader(file));
            //Iterates over the lines of input to count each word.
            String current = null;
            try {
                current = input.readLine();
            } catch (IOException e1) {
                System.err
                        .println("There is a problem with reading the input.");
            }
            while (current != null) {
                int position = 0;
                while (position < current.length()) {
                    String str = nextWordOrSeparator(current, position,
                            separatorSet).toLowerCase();
                    if (separatorStr.indexOf(str) == -1) {
                        if (seq.get(i).equalsIgnoreCase(str)) {
                            count++;
                        }
                    }
                    position += str.length();
                }
                current = null;
                try {
                    current = input.readLine();
                } catch (IOException e) {
                    System.err.println(
                            "There is a problem with reading the input.");
                }
            }
            counts.add(count);
            try {
                input.close();
            } catch (IOException e) {
                System.err.println(
                        "There is a problem with closing the input stream.");
            }
        }
        return counts;
    }

    /**
     * Creates the header of the html page
     *
     * @param out
     *            The output stream.
     */
    private static void createHeader(PrintWriter out) {
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel = " + "\"stylesheet\"" + " type = "
                + "\"text/css\" " + "href = " + "\"data/tagcloud.css\">");
        out.println("</head>");
        out.println("<body>");
    }

    /**
     * Generates the Tag Cloud.
     *
     * @param out
     *            The output stream
     * @param sorter
     *            The sorted map.
     */
    private static void generateCloud(PrintWriter out,
            Map<String, Integer> sorter) {

        ArrayList<Integer> counts = new ArrayList<Integer>();
        Collection<Integer> values = sorter.values();
        for (int c : values) {
            counts.add(c);
        }
        int min = 1;
        int max = maxValue(counts);
        int a = 11;
        int b = 48;
        out.println("<div class = \"cbox\">");
        out.print("<p class = \"cdiv\">");
        Set<String> keys = sorter.keySet();
        int index = 0;
        for (String s : keys) {
            int font = a + (b - a) * (counts.get(index) - min) / (max - min);
            String str = s;
            out.print("<span class = " + "\"f" + font + "\""
                    + "title = \"count:" + counts.get(index) + "\">" + str
                    + "</span>" + " ");
            index++;
        }
        out.println("</p>");
        out.println("</div>");
    }

    /**
     * Returns the index of the maximum value of the sequence
     *
     * @param counts
     *            The sequence to find maximum.
     * @return the index of the maximum
     */
    private static int maxIndex(ArrayList<Integer> counts) {
        int index = 0;
        int max = 0;
        for (int i = 0; i < counts.size(); i++) {
            if (counts.get(i) > max) {
                index = i;
                max = counts.get(i);
            }
        }
        return index;
    }

    /**
     * Returns the maximum value of the sequence
     *
     * @param counts
     *            The sequence to find maximum.
     * @return the index of the maximum
     */
    private static int maxValue(ArrayList<Integer> counts) {
        int max = 0;
        for (int i = 0; i < counts.size(); i++) {
            if (counts.get(i) > max) {
                max = counts.get(i);
            }
        }
        return max;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        BufferedReader in = new BufferedReader(
                new InputStreamReader(System.in));
        //Asks the user for the input or output files.
        System.out.print("Name of an input file: ");
        String input = "";
        try {
            input = in.readLine();
        } catch (IOException e1) {
            System.err.println("There is a problem with reading the input.");
        }
        System.out.print("Name of the output file: ");
        String output = "";
        try {
            output = in.readLine();
        } catch (IOException e1) {
            System.err.println("There is a problem with reading the input.");
        }
        System.out.print("How many words do you want in the tag cloud? ");
        int n = 0;
        try {
            n = Integer.parseInt(in.readLine());
        } catch (NumberFormatException e1) {
            // TODO Auto-generated catch block
            System.err.println("Error: Not a number.");
        } catch (IOException e1) {
            System.err.println("There is a problem with reading the input.");
        }
        PrintWriter out = new PrintWriter(output);
        in = new BufferedReader(new FileReader(input));
        //Creates the HTML Page.
        createHeader(out);
        out.println("<div>");
        out.println("<h1>Top " + n + " words in " + input + "</h1>");
        out.println("</div>");
        //Creates and alphabetically sorts a sequence of the words in the file.
        ArrayList<String> words = makeWords(in);
        Comparator<String> order = new StringComparator();
        Set<String> sorter = new TreeSet<String>(order);
        while (words.size() > 0) {
            sorter.add(words.remove(0));
        }
        Iterator<String> iterator = sorter.iterator();
        while (iterator.hasNext()) {
            String str = iterator.next();
            words.add(str);
        }
        in = new BufferedReader(new FileReader(input));
        //Creates the sequence of the number of times each word appears.
        ArrayList<Integer> numbers = counts(in, sorter, input);
        Map<String, Integer> sortedCloud = new TreeMap<String, Integer>();
        //Check to make sure if n is greater than the number of unique words in the page.
        if (n > sorter.size()) {
            n = sorter.size();
        }
        for (int i = 1; i <= n; i++) {
            int l = maxIndex(numbers);
            sortedCloud.put(words.remove(l), numbers.remove(l));
        }
        generateCloud(out, sortedCloud);
        out.println("</body>");
        out.println("</html>");
        try {
            in.close();
        } catch (IOException e) {
            System.err.println(
                    "There is a problem with closing the input stream.");
        }
        out.close();
    }

}
