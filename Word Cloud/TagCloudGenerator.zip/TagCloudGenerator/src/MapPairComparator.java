import java.util.Comparator;

import components.map.Map;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class MapPairComparator
        implements Comparator<Map.Pair<String, Integer>> {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */

    @Override
    public int compare(Map.Pair<String, Integer> a,
            Map.Pair<String, Integer> b) {
        int result = 0;
        if (a.key().compareToIgnoreCase(b.key()) < 0) {
            result = -1;
        } else if (a.key().compareToIgnoreCase(b.key()) > 0) {
            result = 1;
        }
        return result;
    }
}
